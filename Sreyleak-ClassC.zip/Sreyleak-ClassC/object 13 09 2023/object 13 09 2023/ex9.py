# Ex9 - Array - Object or array dictionary
# fruits = [
#   {'bmc': ['banana','coconut', 'apple','mango']},
#   {'btb': ['orange', 'banana']},
#   {'sr': ['jackfruit','coconut', 'banana']}
# ]
# #1 - Which province has fruit the most?


# *1
# fruits = [
#   {'bmc': ['banana','coconut', 'apple','mango']},
#   {'btb': ['orange', 'banana','banana','coconut', 'apple','mango']},
#   {'sr': ['jackfruit','coconut', 'banana']}
# ]
# newlist = []
# big = len(fruits[0]['bmc'])
# for i in range(len(fruits)):
#   name = input()
#   n = len(fruits[i][name])
#   if big < n:
#     big = n
#     Name = name
# print("the most fruit is "+Name)

# #2 - Which province has coconut
# [
#   {'province': 'bmc'},
#   {'province': 'sr'}  
# ]
# fruits = [
#   {'bmc': ['banana','coconut', 'apple','mango']},
#   {'btb': ['orange', 'banana']},
#   {'sr': ['jackfruit','coconut', 'banana']}
# ]
# def countCoconut(arr):
#     isCoconut=False
#     i=0
#     while i<len(arr) and not isCoconut:
#         if arr[i].upper()=='COCONUT':
#             isCoconut=True
#         i+=1
#     return isCoconut
# arr=[]
# for fruit in fruits:
#     Fruit={}
#     for key in fruit:
#         if countCoconut(key[fruit]):
#             Fruit['province']=key
#     arr.append(Fruit)
# print(arr)

# def coconut(arr):
#     isCoconut=False
#     i=0
#     while i<len(arr) and not isCoconut:
#       if arr[i].upper()=='COCONUT':
#          isCoconut=True
#       i+=1
#     return isCoconut
# fruits = [
#   {'bmc': ['banana','coconut', 'apple','mango']},
#   {'btb': ['orange', 'banana']},
#   {'sr': ['jackfruit','coconut', 'banana']}
# ]
# arr=[]
# for i in range(len(fruits)):
#    Fruit={}
#    name=input("Enter name mk:")
#    if coconut(fruits[i][name]):
#       Fruit['province']=name
#       arr.append(Fruit)
# print(arr)

# #3 - How many banana in fruit list
# {'banana': 3}
# def countBanana(arr):
#     count=0
#     for i in range (len(arr)):
#         if arr[i].upper()=='BANANA':
#             count+=1
#     return count
# fruits = [
#   {'bmc': ['banana','coconut', 'apple','mango']},
#   {'btb': ['orange', 'banana']},
#   {'sr': ['jackfruit','coconut', 'banana']}
# ]
# arr=[]
# count=0
# for i in range(len(fruits)):
#     Fruit={}
#     name=input("Enter name mk:")
#     count+=countBanana(fruits[i][name])
# print(count)

#4 - add mango to btb province
