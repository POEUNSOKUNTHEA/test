# Ex2 - Array
# # String to array seperate by space
# Input: aba bank in Cambodia
# output: ['aba', 'bank','in','Cambodia']
# text=input('enter mk:')
# arr=[]
# res=''
# for i in range(len(text)):
#     if text[i]==' ' or i==len(text)-1:
#         if i==len(text)-1:
#             res+=text[i]
#         arr.append(res)
#         res=''
#     else:
#         res+=text[i]
# print(arr)