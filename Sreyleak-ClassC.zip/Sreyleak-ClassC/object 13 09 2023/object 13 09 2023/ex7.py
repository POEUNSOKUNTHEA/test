# Ex7 - Array
# Array to object - counting character
# input: ['banana','coconut', 'mango', 'orange']
# output: 
# [
#   {'banana':6,'coconut':7,'mango': 5,'orange': 6}
# ]
def countLetter(text):
    return len(text)
arr=['banana','coconut', 'mango', 'orange']
newarr=[]
for i in range(len(arr)):
    fruit={}
    fruit[arr[i]]=countLetter(arr[i])
    newarr.append(fruit)
print(newarr)