#  Ex3 - Array
# # Get only text contains letter A
# Input: ['banana','coconut','mango']
# output: ['banana','mango']

# def letterA(text):
#     isA=False
#     for i in range(len(text)):
#         if text[i].upper()=='A':
#             isA=True
#     return isA
# arr= eval(input())
# newarr=[]
# for i in range(len(arr)):
#     if letterA(arr[i]):
#         newarr.append(arr[i])
# print(newarr)