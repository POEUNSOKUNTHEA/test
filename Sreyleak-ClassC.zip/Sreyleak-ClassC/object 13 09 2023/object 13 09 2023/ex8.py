# Ex8 - Dictionary or object
fruit_stock = [
  {'id': 1, 'name': 'Coconut', 'quatity': 3, 'price': 4000},
  {'id': 2, 'name': 'Banana', 'quatity': 0, 'price': 2500},
  {'id': 3, 'name': 'Mango', 'quatity': 23, 'price': 2000},
  {'id': 4, 'name': 'Orange', 'quatity': 0, 'price': 5000},
  {'id': 5, 'name': 'Apple', 'quatity': 5, 'price': 3000},
  {'id': 6, 'name': 'Jackfruit', 'quatity': 13, 'price': 6000},
]
#1 - How many fruit have price > 3000
# {
#   'numberOfruit': 3,
#   'names': ['Coconut','Orange', 'Jackfruit']
# }
# priceFruit={}
# count=0
# arr=[]
# for fruit in fruit_stock:
#     if fruit['price']>3000:
#         count+=1
#         arr.append(fruit['name'])
# priceFruit['nameOffruit']=count
# priceFruit['names']=arr
# print(priceFruit)

# --------------------
#2 - How many fruit have price < 5000
# [
#   {'name': 'Coconut'},
#   {'name': 'Banana'},
#   {'name': 'Mango'},
#   {'name': 'Apple'}
# ]
# arr=[]
# for fruit in fruit_stock:
#     Fruit={}
#     if fruit['price']<5000:
#         Fruit['name']=fruit['name']
#         arr.append(Fruit)
# print(arr)

# -------------------
#3 - Which fruit doens't have in stock
[
  {'name': 'Banana', 'quatity': 0},
  {'name': 'Orange', 'quatity': 0}
]
arr=[]
for fruit in fruit_stock:
    Fruit={}
    if fruit['quatity']==0:
        Fruit[fruit['name']]=fruit['quatity']
        arr.append(Fruit)
print(arr)