# Ex5 - Array
# #Count number
# Input1: [2, 2, 3, 5, 2, 3, 2, 5, 8]
# Input2: [2, 3]
# Output: [ { 2: 4} , {3: 2} ]


def countnumber(input1,input2):
    count=0
    for i in range(len(input1)):
        if input1[i]==input2:
            count+=1
    return count

Input1= eval(input())
Input2= [2, 3]
arr=[]
for i in range(len(Input2)):
    number={}
    number[Input2[i]]=countnumber(Input1,Input2[i])
    if countnumber(Input1,Input2[i])>0:
        arr.append(number)
print(arr)

