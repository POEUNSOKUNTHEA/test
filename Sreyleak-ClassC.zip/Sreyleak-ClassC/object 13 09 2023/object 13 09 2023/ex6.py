# Ex6 - Array
# Array to object
# input: ['banana','coconut', 'mango', 'orange']
# output: 
# [
#   {0: 'banana',1: 'coconut',2: 'mango',3: 'orange'}
# ]
arr=[]
arr=eval(input())
newarr=[]
for i in range(len(arr)):
    fruit={}
    fruit[arr[i]]=i
    newarr.append(fruit)
print(newarr)

