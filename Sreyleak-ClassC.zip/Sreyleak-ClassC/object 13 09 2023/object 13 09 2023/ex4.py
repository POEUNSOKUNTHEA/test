# Ex4 - Array
# # Reverse array and reverse text in array
# Input: ['banana','coconut']
# output: 
# ['coconut','banana']
# ['ananab','tunococ']
def reverse(text):
    res=''
    for i in range(len(text)):
        res+=text[len(text)-(i+1)]
    return res

arr=eval(input())
newarr=[]
array=[]
for i in range(len(arr)):
    newarr.append(arr[i])
    array.append(reverse(arr[i]))
print(newarr)
print(array)


