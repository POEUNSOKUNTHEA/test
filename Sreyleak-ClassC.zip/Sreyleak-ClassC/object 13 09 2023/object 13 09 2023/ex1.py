# Ex1 - Array
# # String to array
# Input: Hello
# Output: ['H','e','l','l','o']
# text=input('enter mk:')
# arr=[]
# for i in range (len(text)):
#     arr.append(text[i])
# print(arr)

# ------------------


# ------------------
# Ex3 - Array
# # Get only text contains letter A
# Input: ['banana','coconut','mango']
# output: ['banana','mango']

# def letterA(text):
#     isA=False
#     for i in range(len(text)):
#         if text[i].upper()=='A':
#             isA=True
#     return isA
# arr= eval(input())
# newarr=[]
# for i in range(len(arr)):
#     if letterA(arr[i]):
#         newarr.append(arr[i])
# print(newarr)

# ------------------
# Ex4 - Array
# # Reverse array and reverse text in array
# Input: ['banana','coconut']
# output: 
# ['coconut','banana']
# ['ananab','tunococ']

# ------------------
# Ex5 - Array
# #Count number
# Input1: [2, 2, 3, 5, 2, 3, 2, 5, 8]
# Input2: [2, 3]
# Output: [ { 2: 4} , {3: 2} ]

# ------------------
# Ex6 - Array
# Array to object
# input: ['banana','coconut', 'mango', 'orange']
# output: 
# [
#   {0: 'banana',1: 'coconut',2: 'mango',3: 'orange'}
# ]
# Ex7 - Array
# Array to object - counting character
# input: ['banana','coconut', 'mango', 'orange']
# output: 
# [
#   {'banana':6,'coconut':7,'mango': 5,'orange': 6}
# ]
