# Ex1 - String
# text = "38347"
#1 - Sum all number in string (function)

# def Sum(n1,n2):
#     return n1+n2
# text = "38347"
# sum=0
# for i in range(len(text)):
#     sum+=int(text[i])
# print(sum)

#3 - Reverse the string (function)
# def reverse(string):
#     res=''
#     for i in range(len(string)):
#         res+=string[len(string)-(i+1)]
#     return res
# text = "38347"
# print(reverse(text))


#2 - Find average of number in string (function)
# def Averange(string):
#     sum=0
#     averange=1
#     for i in range(len(string)):
#         sum+=int(string)
#     averange=sum/len(string)
#     return averange
# text = "38347"
# print(Averange(text))


