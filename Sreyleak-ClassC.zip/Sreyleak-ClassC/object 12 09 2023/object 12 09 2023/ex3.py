# Ex4 - Array
# input: hello world
# output:
# ['hello', 'world']
# ['h','e','l','l','w','o','r','l','d']
# ['olleh','dlrow']


def Createarr(text):
    arr=[]
    res=''
    for i in range(len(text)):
        if text[i]==" " or i==len(text)-1:
            if i==len(text)-1:
                res+=text[i]
            arr.append(res)
            res=''
        else:
            res+=text[i]
    return arr

def arrOneletter(text):
    arr=[]
    for i in range(len(text)):
        if text[i]!=" ":
            arr.append(text[i])
    return arr
def reverse(text):
    res=''
    for i in range(len(text)):
        res+=text[len(text)-(i+1)]
    return res
def space(text):
    arr=[]
    res=''
    for i in range(len(text)):
        if text[i]==" " or i==len(text)-1:
            if i==len(text)-1:
                res+=text[i]
            arr.append(reverse(res))
            res='' 
        else:
            res+=text[i]
    return arr
text='hello world'
print(Createarr(text))
print(arrOneletter(text))
print(space(text))
