# Ex6 - Array
# arr = ['banana','coconut','mango','Jackfruit','orange','apple']
#1 - Reverse only text contain 1 letter A
# def reverse(text):
#     res=''
#     for i in range(len(text)):
#         res+=text[len(text)-(i+1)]
#     return res

# def Oneletter(text):
#     count=0
#     counter=False
#     for i in range(len(text)):
#         if text[i].upper()=='A':
#             count+=1
#     if count==1:
#         counter=True
#     return counter
# arr = ['banana','coconut','mango','Jackfruit','orange','apple']
# newarr=[]
# for i in range(len(arr)):
#     if Oneletter(arr[i]):
#         newarr.append(reverse(arr[i]))
#     else:
#         newarr.append(arr[i])
# print(newarr)

#2 - Count letter A in text
# [3, 0, 1, 1, 1, 1]
# def countA(text):
#     count=0
#     for i in range(len(text)):
#         if text[i].upper()=='A':
#             count+=1
#     return count
# arr = ['banana','coconut','mango','Jackfruit','orange','apple']
# newarr=[]
# for i in range(len(arr)):
#     newarr.append(countA(arr[i]))
# print(newarr)
#3 - Replace letter A with * in text
def Replace(text):
    res=''
    for i in range(len(text)):
        if text[i].upper()=="A":
            res+="*"
        else:
            res+=text[i]
    return res
arr = ['banana','coconut','mango','Jackfruit','orange','apple']
for i in range(len(arr)):
    arr[i]=Replace(arr[i])
print(arr)