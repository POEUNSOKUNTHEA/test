# Ex3 - Dictionary or object
fruit_stock = [
  {'id': 1, 'name': 'Coconut', 'quality': 3, 'price': 4000},
  {'id': 2, 'name': 'Banana', 'quality': 0, 'price': 2500},
  {'id': 3, 'name': 'Mango', 'quality': 23, 'price': 2000},
  {'id': 4, 'name': 'Orange', 'quality': 0, 'price': 5000},
  {'id': 5, 'name': 'Apple', 'quality': 5, 'price': 3000},
  {'id': 6, 'name': 'Jackfruit', 'quality': 13, 'price': 6000},
]
#1 - How many fruit have in stock
# count=0
# for fruit in fruit_stock:
#     if fruit['name']:
#         count+=1
# print(count)

#2 - How many fruit no more in stock
# Nostock=0
# for fruit in fruit_stock:
#     if fruit['quality']==0:
#         Nostock+=1
# print(Nostock)

#3 - Add 10 fruit to stock which fruti doesn't exist
# for fruit in fruit_stock:
#     if fruit['quality']==0:
#         fruit['quality']=10
# print(fruit_stock)

#4 - Add fruit name to array
# fruita={}
# fruita['name']='orange Juice'
# fruita['id']=7
# fruita['quality']=30
# fruita['price']=1000
# fruit_stock.append(fruita)   
# print(fruit_stock)

#5 - Calculate total of price after add 10 to empty fruit
# Count=1
# for fruit in fruit_stock:
#     if fruit['name']:
#         if fruit['quality']==0:
#             fruit['quality']=10
#         Count=fruit['quality']*fruit['price']
# print(Count)