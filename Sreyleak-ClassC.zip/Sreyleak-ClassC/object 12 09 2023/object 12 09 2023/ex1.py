# Ex1 - Create new object
# Object container: id, name, quality, price
# number of object: 3
# > {'id': 1, 'name': 'Coconut', 'quality': 3, 'price': 100}
# > {'id': 2, 'name': 'Banana', 'quality': 10, 'price': 150}
# > {'id': 3, 'name': 'Mango', 'quality': 23, 'price': 70}
# output:
#   [
#     {'id': 1, 'name': 'Coconut', 'quality': 3, 'price': 100},
#     {'id': 2, 'name': 'Banana', 'quality': 10, 'price': 150},
#     {'id': 3, 'name': 'Mango', 'quality': 23, 'price': 70}
#   ]
def createDicinary (key,value):
    fruit={}
    for i in range(len(key)):
        fruit[key[i]]=value[i]
    return fruit
n=int(input())
fruitlist=[]
key=eval(input())
for i in range(n):
    Value=eval(input())
    la=createDicinary(key,Value)
    fruitlist.append(la)
print(fruitlist)


# ---------------------------
# Ex2 - Dictionary or object
# fruit_stock = [
#   {'id': 1, 'name': 'Coconut', 'quality': 3, 'price': 4000},
#   {'id': 2, 'name': 'Banana', 'quality': 10, 'price': 2500},
#   {'id': 3, 'name': 'Mango', 'quality': 23, 'price': 2000}
# ]

#1 - How many fruit in stock
# countFruit=0
# for fruit in fruit_stock:
#     if fruit['name']:
#         countFruit+=1
# print(countFruit)

#2 - if 1 mango = 2000៛ how much we can get money after sell all mango
# moneyEarn=1
# for fruit in fruit_stock:
#     if fruit['name']=="Mango":
#         moneyEarn=fruit['quality']*fruit['price']
# print(moneyEarn)

#3 - Following price how much money we can get after sell all fruit from stock
# moneyEarnallfruit=0
# for fruit in fruit_stock:
#     moneyEarn=1
#     if fruit['name']:
#         moneyEarn=fruit['quality']*fruit['price']
#     moneyEarnallfruit+=moneyEarn
# print(moneyEarnallfruit)

# ------------------