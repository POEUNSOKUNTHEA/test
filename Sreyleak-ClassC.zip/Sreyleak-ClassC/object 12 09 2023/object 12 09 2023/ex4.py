# Ex5 - Array
# Keep only word with at least 1 letter A
# input: banana coconut mango jackfruit
# ouput:
# banana mango jackfruit
def oneletter(text):
    count=0
    isOne=False
    for i in range(len(text)):
        if text[i].lower()=="a":
            count+=1
    if count>=1:
        isOne=True
    return isOne
text='banana coconut mango jackfruit'
res=''
result=''
for i in range(len(text)):
    if text[i]==' ' or i==len(text)-1:
        if i==len(text)-1:
            res+=text[i]
        if oneletter(res):
            result+=res+" "
        res=''
    else:
        res+=text[i]
print(result)

        
