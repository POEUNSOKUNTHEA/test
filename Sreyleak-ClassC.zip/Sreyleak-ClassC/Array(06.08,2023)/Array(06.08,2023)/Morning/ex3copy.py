
def positionStart(arr):
    index=[]
    isFirst=False
    for i in range(len(array2D)):
        for j in range(len(array2D[i])):
            if arr[i][j]=="*" and not isFirst:
                index.append(i)
                index.append(j)
                isFirst=True
    return index
def star(arr,row):
    isStart=False
    res=""
    for i in range(len(arr)):
        for j in range(len(arr[i])):
            if arr[row][j]=="*" and not isStart:
                isStart=True
            else:
                isStart=False
    if  isStart:
        res="win"
    else:
        res="lost"  
    return res


array2D = [
    ['0','0','0'],
    ['*','*','*'],
    ['0','0','0']
]
curentIndex=positionStart(array2D)
col=curentIndex[0]
row=curentIndex[1]
print(star(array2D,row))