#want to have row and column that easy to watch_______
# 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
# 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
# 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
# 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
# 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
# 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
# 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
# 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
# 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
# def createArray2D(row,col):
#     array2D=[]
#     result=""
#     for i in range(row):
#         array2D.append([])
#         for j in range(col):
#             result+="0 "
#         result+="\n"
#     return result
# row=int(input("Enter row: "))
# column=int(input("Enter column: "))
# print(createArray2D(row,column))

def createArray2D(col):
    array=[]
    for j in range(col):
        array.append('0')
    return array
def displaygrid(grid):
    result=""
    for i in range(len(grid)):
        for j in range(len(grid[i])):
            result+=grid[i][j] + " "
        result+="\n"
    return(result)
row=int(input("Enter row: "))
column=int(input("Enter column: "))
arra2d=[]
for i in range(row):
    arra2d.append(createArray2D(column))
print(displaygrid(arra2d))