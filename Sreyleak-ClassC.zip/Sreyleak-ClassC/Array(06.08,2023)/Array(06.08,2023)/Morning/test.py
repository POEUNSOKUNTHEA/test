# a = { "cambodia": 17, "thailand" : 30, "france" : 45 }

# print(a["cambodia"] )

# countries = { 
# "khmer": 17, 
# "thai" : 30, 
# "vietnam": 50 
# }

# print(countries["khmer"])

# menu =  {}
# menu["MONDAY"] = "rice"
# menu["TUESDAY"] = "noodles"
# menu["MONDAY"] = "soup"

# print(menu["MONDAY"]  )




