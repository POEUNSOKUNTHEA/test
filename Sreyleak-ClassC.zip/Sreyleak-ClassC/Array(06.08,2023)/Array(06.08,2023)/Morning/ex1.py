#______Create row and column in array2D________
#  def createArray2D(row,col):
#     array2D=[]
#     for i in range(row):
#         arr=[]
#         for j in range(col):
#             arr.append(0)
#         array2D.append(arr)
#     return array2D
# row=int(input("Enter row: "))
# column=int(input("Enter column: "))
# print(createArray2D(row,column))

def createArray2D(row,col):
    array2D=[]
    for i in range(row):
        array2D.append([])
        for j in range(col):
            array2D[i].append(0)
    return array2D
row=int(input("Enter row: "))
column=int(input("Enter column: "))
print(createArray2D(row,column))