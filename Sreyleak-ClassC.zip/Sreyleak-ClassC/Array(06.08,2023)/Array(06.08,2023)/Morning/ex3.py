array2D = [
    ['0','0','0'],
    ['*','0','*'],
    ['0','0','0']
]
isStart=False
isSecond=False
isThird=False
for i in range(len(array2D)):
    row=i
    j=0
    while j<len(array2D[i]):
        if array2D[1][j]!="*" and not isStart:
            isStart=True
        j+=1
if  isStart:
    print("Lost")
else:
    print("Win")


# array2D = [
#     ['*','0','0'],
#     ['*','0','0'],
#     ['*','0','0']
# ]
# isStart=False
# i=0
# while i<len(array2D[0]):
#     arr=[]
#     for j in range(len(array2D)):
#         if array2D[j][i]!="*" and not isStart:
#             isStart=True
#         arr.append(arr[j][i])    
#     i+=1
# print(arr)    
# if  isStart:
#     print("Lost")
# else:
#     print("Win")




