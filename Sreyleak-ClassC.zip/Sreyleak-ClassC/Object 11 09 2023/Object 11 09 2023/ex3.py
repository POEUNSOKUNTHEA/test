# Ex3 - Dictionary or object
studentList = [
  {'id': 1, 'name': 'dara', 'salary': 250, 'province':'Phnom Penh'},
  {'id': 2, 'name': 'kaka', 'salary': 540, 'province': 'Ratanakiri'},
  {'id': 3, 'name': 'bopha', 'salary': 562, 'province': 'Siem Riep'},
  {'id': 4, 'name': 'chompa', 'salary': 330, 'province': 'Battambang'},
  {'id': 5, 'name': 'chompey', 'salary': 455, 'province': 'Siem Riep'},
  {'id': 6, 'name': 'romdul', 'salary': 550, 'province': 'Kratie'},
]
#1 - How many student from "Siem Riep"
# count=0
# for student in studentList:
#     if student['province']=='Siem Riep':
#         count+=1
# print(count)

#2 - Find average of student salary
# sum=0
# for student in studentList:
#     if student['salary']:
#         sum+=student['salary']
# print(sum/len(studentList))

#3 - Who has higher salary in list
# ishightest=studentList[0]['salary']
# res=''
# for student in studentList:
#     if student['salary']>ishightest:
#         ishightest=student['salary']
#         res=student['name']
# print(res)

#4 - Increase salary of Kaka to 670
# incressalary=0
# for student in studentList:
#     if student['name']=='kaka':
#         incressalary=student['salary']+(670-student['salary'])
# print(incressalary)

#5 - Rename "romdul" to "សុរិយាច័ន្ទ្រាមហាកញ្ញាបទុមកេសរនារីរ៍ត្ន"
# for student in studentList:
#     if student['name']=='romdul':
#         student['name']='សុរិយាច័ន្ទ្រាមហាកញ្ញាបទុមកេសរនារីរ៍ត្ន'
# print(studentList)

#5 -​ Delete student has id number 5
index=None
for i in range(len(studentList)) :
    if studentList[i]['id']==5:
        index=i
studentList.pop(index)
print(studentList)