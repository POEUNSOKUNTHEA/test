# Ex1 - String
# text = "aba is the bank in cambodia"
#1 - add text to array
# ['aba', 'is', 'the', 'bank', 'in', 'cambodia']
# text = "aba is the bank in cambodia"
# arr=[]
# res=''
# for i in range(len(text)):
#     if text[i]!=" ":
#         res+=text[i]
#     else:
#         if text[i]==" ":
#             arr.append(res)
#             res=''
# arr.append(res)
# print(arr)

#2 - Find first index of "B"
# text = "aba is the bank in cambodia"
# isfirst=False
# index=None
# for i in range(len(text)):
#     if text[i].upper()=="B" and not isfirst:
#         index=i
#         isfirst=True
# print(index)

#3 - Convert text to capitalize
# "Aba Is The Bank In Cambodia"
# text = "aba is the bank in cambodia"
# res=''
# isspace=False
# for i in range(len(text)):
#     if i==0:
#         res+=text[i].upper()
#     elif text[i]==" ":
#         isspace=True
#         res+=text[i]
#     elif isspace:
#         res+=text[i].upper()
#         isspace=False
#     else:
#         res+=text[i]
# print(res)

#4 - Reverse text
# "aba si eht knab ni aidobmac"
def Reverse(text):
    res=''
    for i in range(len(text)):
        res+=text[len(text)-(i+1)]
    return res
text = "aba is the bank in cambodia"
textReverse=''
res=''
for i in range(len(text)):
    if text[i]==" " or i ==len(text)-1:
        if i==len(text)-1:
            res+=text[i]
        textReverse+=Reverse(res)+" "
        res=''
    else:
        res+=text[i]
print(textReverse)