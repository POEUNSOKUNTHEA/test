# Ex4 - Array 2D
# arr2D = [
#   ['*','0','0'],
#   ['*','0','0'],
#   ['*','0','0'],
# ]
#1 - ouput: Win
# arr2D = [
#   ['0','*','0'],
#   ['0','0','0'],
#   ['0','*','0']
# ]
# i = 0
# bool = True
# Run = True
# isfirst=False
# while i < len(arr2D) and Run:
#   j = 0
#   while j < len(arr2D[i]) and bool:
#     if arr2D[j][i] != '*':
#       bool = False
#     j +=1
#   i +=1
#   if bool:
#     isfirst=True
#   else:
#     if not bool:
#       bool=True
# if isfirst:
#   print('win')
# else:
#   print('lost')



# arr2D = [
#   ['0','0','0'],
#   ['0','0','0'],
#   ['*','*','*'], 
# ]
#2 - ouput: Win
# i=0
# bool=True
# Run=True
# isfirst=False
# while i<len(arr2D) and Run:
#   j=0
#   while j<len(arr2D[i]) and bool:
#     if arr2D[i][j]!="*":
#       bool=False
#     j+=1
#   i+=1
#   if bool:
#     isfirst=True
#   else:
#     if not bool:
#       bool=True
# if isfirst:
#   print('win')
# else:
#   print('lost')

# arr2D = [
#   ['*','*','0'],
#   ['0','0','0'],
#   ['0','0','*'],
# ]
#3 - ouput: Win
arr2D = [
  ['0','0','*'],
  ['0','*','0'],
  ['*','0','0'],
]
i = 0
bool = True
Run = True
isfirst=False
while i < len(arr2D) and Run:
  j = 0
  while j < len(arr2D[i]) and bool:
    if arr2D[i][len(arr2D)-(i+1)] != '*':
      bool = False
    j +=1
  i +=1
  if bool:
    isfirst=True
  else:
    if not bool:
      bool=True
if isfirst:
  print('win')
else:
  print('lost')

# arr2D = [
#   ['*','*','0'],
#   ['0','0','0'],
#   ['0','0','*'],
# ]
#4 - ouput: Lose

