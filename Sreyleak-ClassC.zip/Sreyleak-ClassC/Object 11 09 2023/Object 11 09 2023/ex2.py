# /
# arr = [1010, 55, 993, 2]
#1 - How many degit of each number
# [4, 2, 3, 1]
# arr = [1010, 55, 993, 2]
# newarr=[]
# for i in range (len(arr)):
#     count=0
#     n=str(arr[i])
#     newarr.append(len(n))
# print(newarr)

#2 - Reverse array
# arr = [1010, 55, 993, 2]
# newarr=[]
# for i in range(len(arr)):
#     newarr.append(arr[len(arr)-(i+1)])
# print(newarr)

#3 - Sum only number > 2 degit
# arr = [1010, 55, 993, 2]
# newarr=[]
# sum=0
# for i in range (len(arr)):
#     n=str(arr[i])
#     if len(n)>2:
#         sum+=int(n)
# print(sum)
