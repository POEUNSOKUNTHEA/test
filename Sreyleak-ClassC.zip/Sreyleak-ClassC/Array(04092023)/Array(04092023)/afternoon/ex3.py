# arr = [
#   ['0', 'x', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0']
# ]
#1 - Where is the position of x
# def PositionOfX(arr):
#     index=-1
#     for i in range(len(arr)):
#         if arr[i].lower()=='x':
#             index=i
#     return index    
# arr = [
#   ['0', 'x', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0']
# ]
# nono=0
# night=0
# isfirst=True
# for i in range(len(arr)):
#     nono=PositionOfX(arr[i])
#     if nono>=0 and isfirst:
#         night=nono
#         isfirst=False
# if isfirst:
#     print(None)
# else:
#     print(night)


#2 - Move x to last index in first row
#  [
#   ['0', '0', '0', 'x'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0']
# ]
# def PositionOfX(arr):
#     index=-1
#     for i in range(len(arr)):
#         if arr[i].lower()=='x':
#             index=i
#     return index    
# arr = [
#   ['0', 'x', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0']
# ]
# isfirst=True
# nono=0
# for i in range(len(arr)):
#     nono=PositionOfX(arr[i])  
#     print(arr)

# arr = [
#   ['0', 'x', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0']
# ]
# 1 - Where is the position of x
# def PositionOfX(arr):
#     index=-1
#     for i in range(len(arr)):
#         if arr[i].lower()=='x':
#             index=i
#     return index    
# arr = [
#   ['0', 'x', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0']
# ]
# nono=0
# night=0
# isfirst=True
# for i in range(len(arr)):
#     nono=PositionOfX(arr[i])
#     if nono>=0 and isfirst:
#         night=nono
#         isfirst=False
#         arr[i][night]="0"
#         arr[i][night+((len(arr[i])-1)-night)]="x"
# if isfirst:
#     print(arr)
# else:
#     print(arr)


#3 Move x to below
#  [
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', 'x'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0']
# ]
# def PositionOfX(arr):
#     index=-1
#     for i in range(len(arr)):
#         if arr[i].lower()=='x':
#             index=i
#     return index    
# arr = [
#   ['0', 'x', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0'],
#   ['0', '0', '0', '0']
# ]
# nono=0
# night=0
# isfirst=True
# for i in range(len(arr)):
#     nono=PositionOfX(arr[i])
#     if nono>=0 and isfirst:
#         night=nono
#         isfirst=False
#         arr[i][night]="0"
#         arr[i+1][night+((len(arr[i])-1)-night)]="x"
# if isfirst:
#     print(arr)
# else:
#     print(arr)

def PositionOfX(arr):
    index=-1
    for i in range(len(arr)):
        if arr[i].lower()=='x':
            index=i
    return index    
arr = [
  ['0', 'x', '0', '0'],
  ['0', '0', '0', '0'],
  ['0', '0', '0', '0'],
  ['0', '0', '0', '0'],
  ['0', '0', '0', '0']
]
nono=0
night=0
isfirst=True
for i in range(len(arr)):
    nono=PositionOfX(arr[i])
    if nono>=0 and isfirst:
        night=nono
        isfirst=False
        arr[i][night]="0"
        arr[i+1][night+((len(arr[i])-1)-night)]="x"
if isfirst:
    print(arr)
else:
    print(arr)