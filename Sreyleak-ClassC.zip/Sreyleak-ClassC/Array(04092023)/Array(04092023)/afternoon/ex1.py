# Ex1: 
# arr = ['0', '0', 'x', '0', '0', '0', '0']

# #1 - Find index of x
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# index=None
# for i in range(len(arr)):
#     if arr[i].upper()=="X":
#         index=i
# print(index)

# 2 - Replace x by 0 and replace 0 by x
# Newarr=[]
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# for i in range(len(arr)):
#     if arr[i].upper()=="X":
#         Newarr.append(0)
#     elif arr[i]=="0":
#         Newarr.append("x")
# print(Newarr)

# #3 - Move x to next position
#   ['0', '0', '0', 'x', '0', '0', '0']
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# newarr=[]
# for i in range(len(arr)-1):
#     if arr[i].upper()=="X":
#         newarr.append(0)
#         newarr.append("X")
#     else:
#         newarr.append(arr[i])
# print(newarr)
    
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# newarr=[]
# for i in range(len(arr)):
#     if arr[i].upper()=="X" and i<len(arr)-1:
#         newarr.append(arr[i+1])
#     elif arr[i-1].upper()=="X" and i!=0:
#         newarr.append(arr[i-1])
#     else:
#         newarr.append(arr[i])
# print(newarr)

# #4 - Move x to prevouis position
#   ['0', 'x', '0', '0', '0', '0', '0']
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# newarr=[]
# for i in range(len(arr)):
#     if arr[i].upper()=="X" and i<len(arr)-1:
#         newarr.insert(i-1,"X")
#     else:
#         newarr.append(arr[i])
# print(newarr)


# 2 - Replace x by 0 and replace 0 by x
# def indexOfX(array):
#     index=None
#     for i in range(len(array)):
#         if array[i]=="x":
#             index=i
#     return index
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# Curentindex=indexOfX(arr)
# arr[Curentindex]='0'
# arr[Curentindex+1]='x'
# print(arr)


# #4 - Move x to prevouis position
#   ['0', 'x', '0', '0', '0', '0', '0']
# def indexOfX(array):
#     index=None
#     for i in range(len(array)):
#         if array[i]=="x":
#             index=i
#     return index
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# Curentindex=indexOfX(arr)
# arr[Curentindex]='0'
# arr[Curentindex-1]='x'
# print(arr)






