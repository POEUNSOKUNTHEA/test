# Ex2 
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# Enter: right
# To move x to right
# ['0', '0', '0', 'x', '0', '0', '0']
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# newarr=[]
# for i in range(len(arr)):
#     if arr[i].upper()=="X" and i<len(arr)-1:
#         newarr.append(arr[i+1])
#     elif arr[i-1].upper()=="X" and i!=0:
#         newarr.append(arr[i-1])
#     else:
#         newarr.append(arr[i])
# print(newarr)

# Enter: left
# To move x to left
# ['0', 'x', '0', '0', '0', '0', '0']
# arr = ['0', '0', 'x', '0', '0', '0', '0']
# newarr=[]
# for i in range(len(arr)):
#     if arr[i].upper()=="X" and i<len(arr)-1:
#         newarr.insert(i-1,"X")
#     else:
#         newarr.append(arr[i])
# print(newarr)


def indexOfX(array):
    index=None
    for i in range(len(array)):
        if array[i]=="x":
            index=i
    return index
arr = ['0', '0', 'x', '0', '0', '0', '0']
istop=True
while istop:
    Curentindex=indexOfX(arr)
    command=input()
    if command=="stop":
        isStop=False
        print("Ban hy")
    elif command=="right" and Curentindex<len(arr)-1:
        arr[Curentindex]='0'
        arr[Curentindex+1]='x'
        print(arr)
    elif command=="left" and Curentindex!=0:
        arr[Curentindex]='0'
        arr[Curentindex-1]='x'
        print(arr)
    elif command=="left" and Curentindex<=0:
        print(arr)
    else:
        print("Enter again mk bro:( ")











