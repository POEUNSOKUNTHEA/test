# Ex9
# From list of array 2D
# fruits = [
#   ['banana','coconut','mango'],
#   ['jackfruit','banana','mango'],
#   ['papaya','apple','orange'],
#   ['mango','orange','Mango'],
#   ['banana','mango','orange']
# ]

#1 - How many letter "A" from array 2D (function)
# fruits = [
#   ['banana','coconut','mango'],
#   ['jackfruit','banana','mango'],
#   ['papaya','apple','orange'],
#   ['mango','orange','Mango'],
#   ['banana','mango','orange']
# ]
# count=0
# for i in range(len(fruits)):
#     for j in range(len(fruits[i])):
#         for k in range(len(fruits[i][j])):
#             if fruits[i][j][k].upper()=="A":
#                 count+=1
# print(count)

#2 - How many banana in list (function)
# def CountBanana(arr):
#     count=0
#     for i in range(len(arr)):
#         if arr[i].upper()=="BANANA":
#             count+=1
#     return count
# fruits = [
#   ['banana','coconut','mango'],
#   ['jackfruit','banana','mango'],
#   ['papaya','apple','orange'],
#   ['mango','orange','Mango'],
#   ['banana','mango','orange']
# ]
# countBanana=0
# for i in range(len(fruits)):
#     countBanana+=CountBanana(fruits[i])
# print(countBanana)

#3 - How many mango in list (function)
# def CountMango(arr):
#     count=0
#     for i in range(len(arr)):
#         if arr[i].upper()=="MANGO":
#             count+=1
#     return count
# fruits = [
#   ['banana','coconut','mango'],
#   ['jackfruit','banana','mango'],
#   ['papaya','apple','orange'],
#   ['mango','orange','Mango'],
#   ['banana','mango','orange']
# ]
# countmango=0
# for i in range(len(fruits)):
#     countmango+=CountMango(fruits[i])
# print(countmango)

#4 - How many orange in list (function)
# def CountOrange(arr):
#     count=0
#     for i in range(len(arr)):
#         if arr[i].upper()=="ORANGE":
#             count+=1
#     return count
# fruits = [
#   ['banana','coconut','mango'],
#   ['jackfruit','banana','mango'],
#   ['papaya','apple','orange'],
#   ['mango','orange','Mango'],
#   ['banana','mango','orange']
# ]
# countorange=0
# for i in range(len(fruits)):
#     countorange+=CountOrange(fruits[i])
# print(countorange)

#5 - Replace mango by # sign (function)
# def replace(arr):
#     for i in range(len(arr)):
#         if arr[i].upper()=="MANGO":
#             arr[i]="#"
#     return arr
# fruits = [
#   ['banana','coconut','mango'],
#   ['jackfruit','banana','mango'],
#   ['papaya','apple','orange'],
#   ['mango','orange','Mango'],
#   ['banana','mango','orange']
# ]
# for i in range(len(fruits)):
#     n=replace(fruits[i])
#     fruits[i]=n
# print(fruits)




# ___________loop value________________
# def countA(word):
#     count=0
#     for letter in word:
#         if letter.upper()=="A":
#             count+=1
#     return count 
# fruits = [
#   ['banana','coconut','mango'],
#   ['jackfruit','banana','mango'],
#   ['papaya','apple','orange'],
#   ['mango','orange','Mango'],
#   ['banana','mango','orange']
# ]
# counter=0
# for fruitlist in fruits:
#     for fruit in fruitlist:
#         counter+= countA(fruit)
# print(counter)




def countFruit(fruit,name):
    count=0
    for fruit in fruits:
        if fruit.upper()=="BANANA":
            count+=1
    return count 
fruits = [
  ['banana','coconut','mango'],
  ['jackfruit','banana','mango'],
  ['papaya','apple','orange'],
  ['mango','orange','Mango'],
  ['banana','mango','orange']
]
counter=0
for fruitlist in fruits:
    counter+= countFruit(fruitlist,'banana')
print(counter)