# Ex1:
# number of array: 3
# > [3, 3]
# > [1, 3, 4]
# > [4, 5, 9, 1]

# output:
# 6
# 8
# 19
def sum (n1,n2):
    return n1+n2
n=int(input("Enter number of student: "))
result=0
ans=""
for i in range(n):
    arr=eval(input())
    for i in range(len(arr)):
        result=sum(result,arr[i])
print(result)

