# Ex2:
# number of array: 2
# > [3, 2]
# > [1, 3, 4]

# output:
# [2, 3]
# [4, 3, 1]

def reverse(arr):
    res=[]
    for i in range(len(arr)):
        res.append(arr[len(arr)-(i+1)])
    return res
n=int(input("Enter number of student: "))
for i in range(n):
    array=eval(input())
    n=reverse(array)
    print(n)
    
    
