# Ex8
# Search students from list of array 2D
# students = [
#   ['bopha','2024A','kandal'],
#   ['romdule','2024C','kompot'],
#   ['kaka','2024C','Rathanakiri'],
#   ['chompey','2024B','Siem Riep'],
#   ['chompa','2024B','Battambang']
# ]
#1 - how many students from class A? B? and C?
students = [
  ['bopha','2024A','kandal'],
  ['romdule','2024C','kompot'],
  ['kaka','2024C','Rathanakiri'],
  ['chompey','2024B','Siem Riep'],
  ['chompa','2024B','Battambang']
]
# countClassA=0
# countClassB=0
# countClassC=0
# for i in range(len(students)):
#     for j in range(len(students[i])):
#         if students[i][j]=="2024A":
#             countClassA+=1
#         elif students[i][j]=="2024B":
#             countClassB+=1
#         else:
#             if students[i][j]=="2024C":
#                 countClassC+=1
# print("There are:"+ str(countClassA)+" in A " + str(countClassB) +" in B " + str(countClassC)+" in C")

#2 - Where kaka come from?
# res=''
# for i in range(len(students)):
#     for j in range(len(students[i])):
#         if students[i][j].upper()=="KAKA":
#             res=students[i][j+2]
# print(res)

#3 - Which class Chompey study?
# res=''
# for i in range(len(students)):
#     for j in range(len(students[i])):
#         if students[i][j].upper()=="CHOMPEY":
#             res=students[i][j+1]
# print(res)

#4 - Replace Chompa province to Prey Veng
for i in range(len(students)):
    for j in range(len(students[i])):
        if students[i][j].upper()=="CHOMPA":
            students[i][j+2]="Prey Veng"
print(students)



