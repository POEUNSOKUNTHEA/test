# number of array: 2
# > [3, 2]
# > [1, 3, 4]

# output:
# [9, 4]
# [1, 9, 16]


def Square(arr):
    arr1=[]
    square=1
    for i in range(len(arr)):
        square=arr[i]*arr[i]
        arr1.append(square)
        square=1
    return arr1
n=int(input("Enter mk: "))
for i in range(n):
    array=eval(input())
    bong=Square(array)
    print(bong)