# Ex3:
# number of array: 2
# > [3, 2]
# > [1, 3, 4]

# output:
# 2.5
# 2.66666666

# def averange(arr):
#     range=1
#     sum=0
#     for i in range(len(arr)):
#         sum+=arr[i]
#     range=sum/len(arr)
#     return range
# numberOfarray=int(input("Enter mk: "))
# for i in range(numberOfarray):
#     arr1=eval(input())
#     n=averange(arr1)
#     print(n)

# def range(arr):
#     averrange=1
#     sum=0
#     for i in range(len(arr)):
#         sum+=arr[i]
#     averrange=sum/len(arr)
#     return averrange
# n=int(input("Enter number of student: "))
# for i in range(n):
#     array=eval(input())
#     v=range(array)
#     print(v)

def averange(lisofnumber):
    sum=0
    arange=1
    for i in range(len(lisofnumber)):
        sum+=lisofnumber[i]
    arange=sum/len(lisofnumber)
    return arange
n=int(input("Enter number of students:"))
for i in range(n):
    score=eval(input())
    lala=averange(score)
    print(lala)