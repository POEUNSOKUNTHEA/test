# Ex5:
# Find index of number in list (each value is unique)
# def PositionofNumber(arr,number):
#     for i in range(len(arr)):
#         if arr[i]==number:
#             return i
#     return -1
# array=eval(input())
# numberfind=int(input())
# n=PositionofNumber(array,numberfind)
# if n>=0:
#     print(n)
# else:
#     print(str(numberfind) +"not found")


def PositionofNumber(arr,number):
    for i in range(len(arr)):
        if arr[i]==number:
            return i
    return False
array=eval(input())
numberfind=int(input())
n=PositionofNumber(array,numberfind)
if n != False:
    print(n)
else:
    print(str(numberfind) +"not found")

# Test case 1:
# Enter
# Enter number: 10
# ouput
# 10 at position 3
# def PositionofNumber(arr,number):
#     index=None
#     for i in range(len(arr)):
#         if arr[i]==number:
#             index=i
#     return index
# array= [1,2,4,10,9]
# number=10
# print(PositionofNumber(array,number))


# Test case 2:
# Enter array: [5,4,10,3]
# Enter number: 5
# ouput
# 5 at position 0
# def PositionofNumber(arr,number):
#     index=None
#     for i in range(len(arr)):
#         if arr[i]==number:
#             index=i
#     return index
# array= [1,2,4,10,9]
# number=10
# print(PositionofNumber(array,number))

# Test case 3:

# Enter array: [5,4,10,3]
# Enter number: 8
# ouput
# 8 not found in list