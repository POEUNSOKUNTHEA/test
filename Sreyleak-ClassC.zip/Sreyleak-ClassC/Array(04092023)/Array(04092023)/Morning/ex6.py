# Ex6:
# Count number in list 
# Test case 1:
# def CountNumber(arr,number):
#     count=0
#     for i in range(len(arr)):
#         if arr[i]==number:
#             count+=1
#     return count
# array=eval(input())
# number=int(input())
# print(CountNumber(array,number))

# Enter array: [1,2,4,10,9]
# Enter number: 10
# ouput
# number 10 is 1
def CountNumber(arr,number):
    count=0
    for i in range(len(arr)):
        if arr[i]==number:
            count+=1
    return count
array=[1,2,4,10,9]
number= 10
print(CountNumber(array,number))
# Test case 2:

# Enter array: [5,4,5, 5, 5, 10,3]
# Enter number: 5
# ouput: 

# number 5 is 4

# Test case 3:

# Enter array: [5,4,10,3]
# Enter numbe 8
# ouput
# number 8 is 0