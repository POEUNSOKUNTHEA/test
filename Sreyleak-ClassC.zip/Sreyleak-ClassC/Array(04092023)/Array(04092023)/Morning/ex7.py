# Ex7:
# Count number 10 in list of array 2D
# Test case 1:
# def count(arr,number):
#     count=0
#     for i in range(len(arr)):
#         if arr[i]==number:
#             count+=1
#     return count
# array2D=eval(input())
# numb=int(input())
# sum=0
# for i in range(len(array2D)):
#     sum+=count(array2D[i])
# print(sum)
# Enter array: [[1, 2, 4, 5], [14, 16, 10, 11], [10, 9, 10, 10]]
# ouput
# number 10 is 4
# def Count(arr):
#     count=0
#     for i in range(len(arr)):
#         if arr[i]==10:
#             count+=1
#     return count
# array2D=[[1, 2, 4, 5], [14, 16, 10, 11], [10, 9, 10, 10]]
# sum=0
# for i in range(len(array2D)):
#     sum+=Count(array2D[i])
# print(sum)


# Test case 2:
# Enter array: [[1, 2, 4, 5], [14, 16, 8, 11], [8, 9, 8, 8]]
# ouput
# number 10 is 0
def Count(arr):
    count=0
    for i in range(len(arr)):
        if arr[i]==10:
            count+=1
    return count
array2D=[[1, 2, 4, 5], [14, 16, 8, 11], [8, 9, 8, 8]]
sum=0
for i in range(len(array2D)):
    sum+=Count(array2D[i])
print(sum)