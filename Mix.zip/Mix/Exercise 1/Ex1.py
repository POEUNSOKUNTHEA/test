# Ex1 - String
text = "aba is the bank in cambodia"

#1 - add text to array
# result=''
# arr=[]
# for i in range(len(text)):
#     if text[i]!=" ":
#         result+=text[i]
#     elif text[i]==' ':
#         arr.append(result)
#         result=''
#     if i==len(text)-1:
#         arr.append(result)
# print(arr)



#2 - Find first index of "B"
# isfound=True
# i=0
# while i<len(text) and isfound:
#     if text[i].upper()=="B":
#         Index=i
#         isfound=False
#     i+=1
# print(Index)



#3 - Convert text to capitalize
# isFirst=True
# result=''
# for i in range(len(text)):
#     if text[i]!=" " and isFirst:
#         result+=text[i].upper()
#         isFirst=False
#     elif text[i]==' ':
#         result+=text[i]
#         isFirst=not isFirst
#     elif text[i]!=" ":
#         result+=text[i]
# print(result)



# "Aba Is The Bank In Cambodia"
#4 - Reverse text
# world=''
# result=''
# for i in range(len(text)):
#     if text[i]!=" ":
#         world+=text[i]
#     elif text[i]==" ":
#         for i in range(len(world)):
#             result+=world[len(world)-i-1]
#         result+=" "
#         world=''
#     if i==len(text)-1:
#         for i in range(len(world)):
#             result+=world[len(world)-i-1]
# print(result)



#5 - add number of text to array
# sum=0
# arr=[]
# for i in range(len(text)):
#     if text[i]!=" ":
#         sum+=1
#     elif text[i]==' ':
#         arr.append(sum)
#         sum=0
#     if i==len(text)-1:
#         arr.append(sum)
# print(arr)
