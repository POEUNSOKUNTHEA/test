# Ex4 - Array 2D
# #1 - ouput: Win



# arr2D = [
#   ['*','0','0'],
#   ['*','0','0'],
#   ['*','0','0'],
# ]
# i=0
# result="Lose"
# while i<len(arr2D):
#   count=0
#   for j in range(len(arr2D[i])):
#     if arr2D[j][i]=="*":
#       count+=1
#   if count==3:
#     result="Win"
#   i+=1
# print(result)


# #2 - ouput: Win
# arr2D = [
#   ['*','*','*'],
#   ['0','0','0'],
#   ['0','0','0'],
# ]
# result="lose"
# for i in range(len(arr2D)):
#   count=0
#   for j in range(len(arr2D[i])):
#     if arr2D[i][j]=="*":
#       count+=1
#   if count==3:
#     result="Win"
# print(result)



# #2 - ouput: Win
# arr2D = [
#   ['*','0','0'],
#   ['0','*','0'],
#   ['0','0','*'],
# ]
# result="lose"
# for i in range(len(arr2D)):
#   count=0
#   for j in range(len(arr2D[i])):
#     if arr2D[j][j]=="*":
#       count+=1
#   if count==3:
#     result="Win"
# print(result)



#4 - ouput: Lose
# arr2D = [
#   ['*','*','0'],
#   ['0','0','0'],
#   ['0','0','*'],
# ]
# result="lose"
# for i in range(len(arr2D)):
#   count=0
#   for j in range(len(arr2D[i])):
#     if arr2D[j][j]=="*":
#       count+=1
#   if count==3:
#     result="Win"
# print(result)