# Ex2 - Array
arr = [1010, 55, 993, 2]
#1 - How many degit of each number
# newarr=[]
# for i in range(len(arr)):
#     res=str(arr[i])
#     sum=0
#     for j in range(len(res)):
#         sum+=1
#     newarr.append(sum)
# print(newarr)
# [4, 2, 3, 1]



#2 - Reverse array
# newarr=[]
# for i in range(len(arr)):
#     result=0
#     result+=arr[len(arr)-i-1]
#     newarr.append(result)
# print(newarr)



#3 - Sum only number > 2 degit
# result=0
# for i in range(len(arr)):
#     res=str(arr[i])
#     sum=0
#     for j in range(len(res)):
#         sum+=1
#     if sum>2:
#         result+=int(res)
# print(result)