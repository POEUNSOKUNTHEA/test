# Ex2 - Dictionary or object
fruit_stock = [
  {'id': 1, 'name': 'Coconut', 'quality': 3, 'price': 4000},
  {'id': 2, 'name': 'Banana', 'quality': 10, 'price': 2500},
  {'id': 3, 'name': 'Mango', 'quality': 23, 'price': 2000}
]

#1 - How many fruit in stock
# count=0
# for key in fruit_stock:
#     count+=key['quality']
# print(count)


#2 - if 1 mango = 2000៛ how much we can get money after sell all mango
# result=1
# for key in fruit_stock:
#     if key['name'].upper()=="MANGO":
#         result=key['quality']*key['price']
# print(result)


#3 - Following price how much money we can get after sell all fruit from stock
# result=0
# number=0
# Total=1
# for key in fruit_stock:
#     result+=key['price']
#     number+=key['quality']
# Total=result*number
# print(Total)