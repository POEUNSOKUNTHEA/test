# Ex6 - Array

arr = ['banana','coconut','mango','Jackfruit','orange','apple']
#1 - Reverse only text contain 1 letter A
# def reverseString(word):
#     result=''
#     for i in range(len(word)):
#         result+=word[len(word)-1-i]
#     return result
# def oneLetter(list):
#     count=0
#     isfound=False
#     for i in range(len(list)):
#         if list[i].upper()=="A":
#             count+=1
#     if count==1:
#         isfound=True
#     return isfound
# newarr=[]
# for i in range(len(arr)):
#     if oneLetter(arr[i]):
#         newarr.append(reverseString(arr[i]))
#     else:
#         newarr.append(arr[i])
# print(newarr)

    
        
#2 - Count letter A in text
# def countA(word):
#     count=0
#     for i in range(len(word)):
#         if word[i].upper()=="A":
#             count+=1
#     return count
# newarr=[]
# for i in range(len(arr)):
#     newarr+=countA(arr[i])
# print(newarr)

# [3, 0, 1, 1, 1, 1]
#3 - Replace letter A with * in text
# def replace(word):
#     result=''
#     for i in range(len(word)):
#         if word[i].upper()=="A":
#             result+="*"
#         else:
#             result+=word[i]
#     return result
# for i in range(len(arr)):
#     arr[i]=replace(arr[i])
# print(arr)