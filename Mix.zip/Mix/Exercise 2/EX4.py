# Ex4 - Array

text="hello world"


def make_arr(text):
    result=''
    arr=[]
    for i in range(len(text)):
        if text[i]!=" ":
            result+=text[i]
        elif text[i]==" ":
            arr.append(result)
            result=''
        if i==len(text)-1:
            arr.append(result)
    return arr

def make_string_one_by_one(text):
    arr=[]
    for i in range(len(text)):
        if text[i]!=" ":
            arr.append(text[i])
    return arr

def reverse_string_in_arr(text):
    result=''
    word=''
    arr=[]
    for i in range(len(text)):
        if text[i]!=" ":
            result+=text[i]
        elif text[i]==" ":
            for i in range(len(result)):
                word+=(result[len(result)-i-1])
            arr.append(word)
            result=''
            word=''
        if i==len(text)-1:
            for i in range(len(result)):
                word+=(result[len(result)-i-1])
            arr.append(word)
    return arr
    
print(make_arr(text))
print(make_string_one_by_one(text))
print(reverse_string_in_arr(text))

# output:
# ['hello', 'world']
# ['h','e','l','l','w','o','r','l','d']
# ['olleh','dlrow']