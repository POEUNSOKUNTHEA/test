# Ex5 - Array
# Keep only word with at least 1 letter A
# input: banana coconut mango jackfruit
text="banana coconut mango jackfruit"
result=''
word=''
for i in range(len(text)):
    if text[i]!=" ":
        word+=text[i]
    elif text[i]==" ":
        isfound=True
        for i in range(len(word)):
            if word[i].upper()=="A" and isfound:
                result+=word
                isfound=False
        result+= " "
        word=''
    if i==len(text)-1:
        for i in range(len(word)):
            if word[i].upper()=="A":
                result+=word
print(result)

# ouput:
# banana mango jackfruit