# Ex5 - Array
#Count number
arr1= [2, 2, 3, 5, 2, 3, 2, 5, 8]
arr2= [2, 3]

def countNumber(arr,value):
    count=0
    for num in arr:
        if num==value:
            count+=1
    return count
arr=[]
for num in arr2:
    arr.append({num:countNumber(arr1,num)})
print(arr)


Output: [ { 2: 4} , {3: 2} ]