# Ex3 - Array
# Get only text contains letter A
Input= ['banana','coconut','mango']
def countA(list):
    isfound=True
    i=0
    while i<len(list) and isfound:
        if list[i].upper()=="A":
            isfound=False
        i+=1
    return not isfound
newarr=[]
for value in Input:
    if countA(value):
        newarr.append(value)

print(newarr)

output: ['banana','mango']