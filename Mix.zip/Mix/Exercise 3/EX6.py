# Ex6 - Array
# Array to object
arr= ['banana','coconut', 'mango', 'orange']
result=[]
for i in range(len(arr)):
  result.append({i: arr[i]})
print(result)
  


# output: 
# [
#   {0: 'banana',1: 'coconut',2: 'mango',3: 'orange'}
# ]