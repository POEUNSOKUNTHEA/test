# Ex2 - Array
# String to array seperate by space
Input= "aba bank in Cambodia"
res=""
arr=[]
for i in range(len(Input)):
    if Input[i]!=" ":
        res+=Input[i]
    elif Input[i]==" ":
        arr.append(res)
        res=''
    if i==len(Input)-1:
        arr.append(res)
print(arr)


# output: ['aba', 'bank','in','Cambodia']