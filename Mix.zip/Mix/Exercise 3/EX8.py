# Ex8 - Dictionary or object
fruit_stock = [
  {'id': 1, 'name': 'Coconut', 'quatity': 3, 'price': 4000},
  {'id': 2, 'name': 'Banana', 'quatity': 0, 'price': 2500},
  {'id': 3, 'name': 'Mango', 'quatity': 23, 'price': 2000},
  {'id': 4, 'name': 'Orange', 'quatity': 0, 'price': 5000},
  {'id': 5, 'name': 'Apple', 'quatity': 5, 'price': 3000},
  {'id': 6, 'name': 'Jackfruit', 'quatity': 13, 'price': 6000},
]
#1 - How many fruit have price > 3000
  


# find_count_fruits={}
# count=0
# result=[]
# for key in fruit_stock:
#     if key['price']>3000:
#         count+=1
#         result.append(key['name'])
# find_count_fruits['numberOfruit']=count
# find_count_fruits['names']=result
# print(find_count_fruits)

# {
#   'numberOfruit': 3,
#   'names': ['Coconut','Orange', 'Jackfruit']
# }



#2 - How many fruit have price < 5000
# result=[]
# for object in fruit_stock:
#     if object['price']<5000:
#         result.append({'name':object['name']})
# print(result)

# [
#   {'name': 'Coconut'},
#   {'name': 'Banana'},
#   {'name': 'Mango'},
#   {'name': 'Apple'}
# ]


#3 - Which fruit doens't have in stock
# result=[]
# for object in fruit_stock:
#     if object['quatity']==0:
#         result.append({'name':object['name'],'quatity':object['quatity']})
# print(result)

[
  {'name': 'Banana', 'quatity': 0},
  {'name': 'Orange', 'quatity': 0}
]