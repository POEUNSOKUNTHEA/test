# Ex1 - Array
# String to array
Input= "Hello"
arr=[]
for i in range(len(Input)):
    arr.append(Input[i])
print(arr)

# Output: ['H','e','l','l','o']
