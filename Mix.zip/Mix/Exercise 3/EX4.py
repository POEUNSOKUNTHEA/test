# Ex4 - Array
# Reverse array and reverse text in array
Input= ['banana','coconut']
for i in range(len(Input)):
    word=Input[i]
    result=''
    for j in range(len(word)):
        result+=word[len(word)-1-j]
    Input[i]=result
print(Input)

# output: 
# ['coconut','banana']
# ['ananab','tunococ']