# Ex7 - Array
# Array to object - counting character
arr= ['banana','coconut', 'mango', 'orange', 'papaya']
result=[]
for value in arr:
  count=0
  for i in range(len(value)):
    count+=1
  result.append({value:count})
print(result)

# output: 
# [
#   {'banana':6,'coconut':7,'mango': 5,'orange': 6}
# ]