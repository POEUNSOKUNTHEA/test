# Ex9 - Array - Object or array dictionary
fruits = [
  {'bmc': ['banana','coconut']},
  {'btb': ['orange', 'banana','apple','mango']},
  {'sr': ['jackfruit','coconut', 'banana']}
]
#1 - Which province has fruit the most?
# max=len(fruits[0]['bmc'])
# for i in range(len(fruits)):
#     word=fruits[i]
#     for key in word:
#         result=len(word[key])
#         name=key
#     if max<result:
#         max=result
#         res=name
# print(res)

#2 - Which province has coconut
newarr=[]
for i in range(len(fruits)):
    word=fruits[i]
    for key in word:
        result=word[key]
        if result=='banana':
            newarr.append({'provice':key})
print(newarr)

# [
#   {'province': 'bmc'},
#   {'province': 'sr'}  
# ]
#3 - How many banana in fruit list
{'banana': 3}
#4 - add mango to btn province