# Ex1 - Object

# #Question - Add items to object with difference price
#     name : banana , price : 2
#     name : coconut , price : 4
#     name : mango , price : 3
result=[]
object1 = {}
object1['name']='banan'
object1['price']=2
result.append(object1)

object2 = {}
object2['name']='mango'
object2['price']=3
result.append(object2)

object3 = {}
object3['name']='coconut'
object3['price']=4
result.append(object3)
print(result)