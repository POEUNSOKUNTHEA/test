# Ex2 - Dictionary
# fruit_stock = {'banana': 3, 'coconut': 30, 'mango': 21}

#1 - Add new fruit: Orange with amount of 100
# fruit_stock['orange']=100
# print(fruit_stock)



#2 - Find average all fruits
# sum=0
# count=0
# for key in fruit_stock:
#     sum+=fruit_stock[key]
#     count+=1
# print(int(sum/count))

#3 - Find total fruit in stock
# sum=0
# for key in fruit_stock:
#     sum+=fruit_stock[key]
# print(sum)


#4 - Now change fruit_stock to be input that you can input differneces fruit
object=eval(input())
print(object)