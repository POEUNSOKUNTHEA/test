# Ex1 - Array
# input1: hello
# output: olleh

# text=input()
# result=""
# for i in range(len(text)):
#     result+=text[len(text)-i-1]
# print(result)


# Ex2 - Array
# input1: hello
# output: ['o','l','l','e','h']

# text=input()
# arr=[]
# for i in range(len(text)):
#     arr.append(text[len(text)-i-1])
# print(arr)


# Ex3 - Array
# input1: ['banana','coconut']
# ouput: ['ananab','tunococ']

# arr=eval(input())

# newarr=[]
# for i in range(len(arr)):
#     result=''
#     for j in range(len(arr[i])):
#         result+=arr[i][len(arr[i])-j-1]
#     newarr.append(result)
# print(newarr)
    

# Ex4 - Array use only 1 function
# Case 1:
# input: [1, 3, 4, 4]
# input: odd
# output: 4

def find_number(number,value):
    isfound=False
    
    if number%2==1 and value=='odd':
        isfound=True
    return isfound
arr=eval(input())
text=input()
sum=0
for i in range(len(arr)):
    if find_number(arr[i],text):
        sum+=arr[i]
print(sum)
        


# Case 2:
# input: [1, 3, 4, 4]
# input: even
# output: 8

# case 3:
# input: [1, 3, 4, 4]
# input: add
# output: Command not found
# -----
# Ex5 - Array
# input: ['banana', 'coconut']
# output: 
# [
#   {'b': 1},
#   {'a': 3},
#   {'n': 3},
#   {'c': 2},
#   {'o': 2},
#   {'u': 1},
#   {'t': 1},
# ]