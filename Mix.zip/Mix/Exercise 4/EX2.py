# Ex2 - Array
# Find index
# input1: [3, 3, 4, 5, 6, 6]
# input2: [3, 4, 6]

arr1=eval(input("Enter here "))
arr2=eval(input("Enter here "))
def findNumber(arr,value):
    index=""
    for i in range(len(arr)):
        if arr[i]==value:
            index+=str(i)
    return index
result={}
for n in arr2:
    result[n]=findNumber(arr1,n)
print(result)

# ouput: {3: "01", 4: "2", 6:"45"}