# Ex1 - Array
# input1: ['banana','coconut','mango']
# input2: ['a','o']
list1=['banana','coconut','mango']
list2=['a','o']
def countLetter(arr,value):
    isfound=True
    count=0
    for j in range(len(arr)):
        for i in range(len(arr[j])):
            if arr[j][i]==value:
                count+=1
    return count
result={}
for value in list2:
    result[value]=countLetter(list1,value)
print(result)

# output:
# # {'a': 4, 'o': 3]