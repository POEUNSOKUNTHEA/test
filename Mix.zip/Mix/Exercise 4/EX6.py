
# Ex6 - object
arr1= ['banana','coconut','mango']
arr2= [0,2]

def count_letter(letter):
    result={}
    for i in range(len(letter)):
        result[i]=letter[i]
    return result

def create_object(arr,index,value):
    result=None
    for i in range(len(value)):
        if index==value[i]:
            result=count_letter(arr)
    return result
result=[]
for i in range(len(arr1)):
    word=(create_object(arr1[i],i,arr2))
    if word!=None:
        result.append(word)
print(result)
        

# [
#   {0:'b',1:'a', 2:'n', 3: 'a', 4: 'n',5:'a'},
#   {0:'m',1:'a', 2:'n', 3: 'g', 4: 'o'},
# ]