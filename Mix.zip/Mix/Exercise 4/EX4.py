# Ex4 - Array
# #Get value by index
# input1: ['banana','coconut','mango']
# input2: [0, 2]
arr1=eval(input("Enter here "))
arr2=eval(input("Enter here "))
def putIndex(arr,value):
    name=None
    for i in range(len(arr)):
        if i==value:
            name=arr[i]
    return name
result={}
for n in arr2:
    result[n]=putIndex(arr1,n)
print(result)



# output:
# {0: 'banana', 2: 'mango'}