# Ex8 - Object
# #Reverse Object
input= {1: 'banana', 2: 'mango', 3: 'coconut'}
for key in input:
    word=input[key]
    result=""
    for i in range(len(word)):
        result+=word[len(word)-1-i]
    input[key]=result
print(input)
    


# output: {1: 'ananab', 2: 'ognam', 3: 'tunococ'}