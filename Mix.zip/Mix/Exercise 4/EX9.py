
# Ex9 - Array
# #Replace character by something
# arr1= ['banana','coconut','mango']
# arr2= ['a', '*']
# # output:
# # ['b*n*n*','coconut','m*ngo']

# def replace(letter,value1,value2):
#     isfound=False
#     word=""
#     for i in range(len(letter)):
#         if letter[i]==value1:
#             word+=value2
#         else:
#             word+=letter[i]
#     return word
# result=[]
# for i in range(len(arr1)):
#     result.append(replace(arr1[i],arr2[0],arr2[1]))
# print(result)


