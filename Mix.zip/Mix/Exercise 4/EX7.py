# Ex7 - Array 2D
input= [3,4, 5, 1]
result=[]
for i in range(len(input)):
    number=input[i]
    list=[]
    for j in range(1,number+1):
        list.append(j)
    result.append(list)
print(result)

# ouput: 
# [
#   [1, 2, 3],
#   [1, 2, 3, 4],
#   [1, 2, 3, 4, 5],
#   [1]
# ]