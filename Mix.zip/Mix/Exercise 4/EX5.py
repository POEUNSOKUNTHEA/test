
# Ex5 - Array
# #Reverse text by index

# arr1= ['banana','coconut','mango']
# arr2= [0,2]
# def reverse_by_index(arr,index,value):
#         for i in range(len(value)):
#             if index==int(value[i]):
#                 result=""
#                 for i in range(len(arr)):
#                     result+=arr[len(arr)-i-1]
#                 return result
#         else:
#             return arr
# result=[]
# for i in range(len(arr1)):
#     result.append(reverse_by_index(arr1[i],i,arr2))
# print(result)
        
# output:
# ['ananab','coconut','ognam']