def isEqual(array1,array2):
    isEqual=True
    if len(array1)!=len(array2):
        isEqual=False
    for i in range(len(array1)):
        if array1[i]!=array2[i]:
            isEqual=False
    return isEqual
array2D1=eval(input())
array2D2=eval(input())
equal="equal"
for i in range(len(array2D1)):
    if isEqual(array2D1[i],array2D2[i])==False:
        equal="not equal"
print(equal)
    