# def Replace7To8(array):
#     for i in range(len(array)):
#         if array[i]==7:
#             array[i]=8
#     return array
# array2D=[[1,3,5,7],[3,5,7],[2,5,7,8]]
# for i in range(len(array2D)):
#     array2D[i]= Replace7To8(array2D[i])
# print(array2D)

# def sum_column(array2D):
#     sums = []
#     num_cols = len(array2D[0])
#     for i in range(num_cols):
#         total = 0
#         for j in range(len(array2D)):
#             total += array2D[j][i]
#         sums.append(total)
#     return sums


# array2D = eval(input())
# print(sum_column(array2D))


# def sum_number(array2D):
#     sum=0
#     for i in range (len(array2D)):
#        if i<3:
#         for j in range(len(array2D)):
#             sum+= array2D[j][i]
#     return sum

# print(sum_number( [[1,2,3,4],[5,6,7,8],[8,9,10,11]]))


# def UpperLetter(array):
#     result=[]
#     for i in range(len(array)):
#         result.append(array[i].upper())
#     return result

# array2D=eval(input())
# for i in range(len(array2D)):
#     array2D[i]=UpperLetter(array2D[i])
# print(array2D)


# def findMaxnumber(array):
#     max = array[0]
#     for i in range(len(array)):
#         if array[i] > max :
#             max = array[i]
#     return max

# array2D=eval(input())
# for i in range(len(array2D)):
#     array2D[i]=findMaxnumber(array2D[i])
# print(array2D)

# def replaceletter(array):
#     change=[]
#     for i in range(len(array)):
#         change.append("*")
#     return change
# Text=eval(input())
# textrow=int(input())
# Text[textrow] = replaceletter(Text[textrow])
# print(Text)


# def replaceletter(array):
#     for i in range(len(array)):
#         array[i]="*"
#     return array
# Text=eval(input())
# textrow=int(input())
# Text[textrow] = replaceletter(Text[textrow])
# print(Text)
        

