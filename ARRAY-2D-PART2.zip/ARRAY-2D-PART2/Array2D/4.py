def convertLetter(array):
    sumLetter =''
    for i in range(len(array)):
        sumLetter += array[i]
    return sumLetter

array2D = [['b','a','n','a','n','a'],['c','o','c','o','n','u','t']]
for i in range(len(array2D)):
    array2D[i]=convertLetter(array2D[i])
print(array2D)