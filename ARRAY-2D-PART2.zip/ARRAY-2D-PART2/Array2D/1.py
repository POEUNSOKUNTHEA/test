array2D=[[5,3,8,4],[3,8,8,1],[1,7,5,3]]
result=[]
for i in range(len(array2D)):
    for J in range(len(array2D[i])):
        if array2D[i][J]==7:
            result.append(i)
            result.append(J)
print(result)




# def number(array2D):
#     result=[]
#     for i in range(len(array2D)):
#         for J in range(len(array2D[i])):
#             if array2D[i][J]==7:
#               result.append(i)
#               result.append(J)
#     return result
# array=[[5,7,8,4],[3,8,7,1],[1,4,6,3]]
# print(number(array))