# def changecolunmToStar(array2D):
#     for i in range(len(array2D[0])):
#         if i == column:
#             for j in range(len(array2D)):
#                 array2D[j][i] = '*'
#     return array2D

# array2D=[["A", "B"], ["D", "F"], ["V", "D"]]
# column = int(input("enter: "))
# print(changecolunmToStar(array2D))



def replaceletertTostar(array,index):
    for i in range (len(array)):
            array[index]="*"
    return array
array2D=[['A','B','S'],["A","R","t"]]
column=int(input())
for i in range(len(array2D)):
    if column<len(array2D[0]):
        array2D[i]=replaceletertTostar(array2D[i],column)
    else:
        array2D="column error"
print(array2D)

