array=[[1,0,0],[0,0,0],[0,0,0]]
row = 0
col = 0
res="CANNOT ADD"
def CountNumber(array):
    count=0
    for i in range(len(array)):
        for J in range(len(array[i])):
            if array[i][J] ==1:
                count+=1
    return count
if array[row][col] !=1 and CountNumber(array) <=2:
    res='CAN ADD'
print(res)

