array2D =[[0,0,0],
          [0,"*",0],
          [0,0,0]]
word = input("enter:")
if word == "U":
    array2D[0][1]= array2D[1][1]
    array2D[1][1] = 0
    print(array2D)
elif word == "D":
    array2D[2][1]= array2D[1][1]
    array2D[1][1] = 0
    print(array2D)
elif word == "R":
    array2D[1][2]= array2D[1][1]
    array2D[1][1] = 0
    print(array2D)
elif word == "L":
    array2D[1][0]= array2D[1][1]
    array2D[1][1] = 0
    print(array2D)