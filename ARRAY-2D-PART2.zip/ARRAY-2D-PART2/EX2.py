def count_letter_a(text):
    counts = 0
    for i in range (len(text)):
        if text[i] == "a":
            counts +=1
    return counts

def count_Total_A(array):
    total = 0
    for i in range(len(array)):
        total += count_letter_a(array[i])
    return total

array2D=[['apple', 'banana', 'cherry'], ['dog', 'elephant', 'fox'], ['grape', 'kiwi', 'lemon']]
for i in range(len(array2D)):
    array2D[i] = count_Total_A(array2D[i])
print(array2D)
