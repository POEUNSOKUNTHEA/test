def  findPositionOfCapitain(array2D):
    result = []
    for i in range(len(array2D)):
        for J in range (len(array2D[i])):
            if array2D[i][J] == "*":
                result.append(i)
                result.append(J)
    return result

def moveCaptitaineTonextright(array2D,positionOfCapitaine):
    if len(positionOfCapitain)==0 or positionOfCapitain[1]== len(array2D)-1:
        return array2D
    row = positionOfCapitaine[0]
    column = positionOfCapitaine[1]
    array2D[row][column] = array2D[row][column+1]
    array2D[row][column+1] = "*"
    return array2D

def moveCaptitaineTonextLeft(array2D,positionOfCapitaine):
    if len(positionOfCapitain)==0 or positionOfCapitain[1]== 0:
        return array2D
    row = positionOfCapitaine[0]
    column = positionOfCapitaine[1]
    array2D[row][column] = array2D[row][column-1]
    array2D[row][column-1] = "*"
    return array2D

def moveCaptitaineTonextUp(array2D,positionOfCapitaine):
    if len(positionOfCapitain)==0 or positionOfCapitain[1]== 0:
        return array2D
    row = positionOfCapitaine[0]
    column = positionOfCapitaine[1]
    array2D[row][column] = array2D[row-1][column]
    array2D[row-1][column] = "*"
    return array2D

def moveCaptitaineTonextDown(array2D,positionOfCapitaine):
    if len(positionOfCapitain)==0 or positionOfCapitain[1]== len(array2D)-1:
        return array2D
    row = positionOfCapitaine[0]
    column = positionOfCapitaine[1]
    array2D[row][column] = "0"
    array2D[row + 1][column] = "*"
    return array2D


def moveCaptitaineTonextUpright(array2D,positionOfCapitaine):
    if len(positionOfCapitain)==0 or positionOfCapitain[1]== len(array2D)-1:
        return array2D
    row = positionOfCapitaine[0]
    column = positionOfCapitaine[1]
    array2D[row][column] = "0"
    array2D[row - 1][column +1] = "*"
    return array2D

def moveCaptitaineTonextUpLeft(array2D,positionOfCapitaine):
    if len(positionOfCapitain)==0 or positionOfCapitain[1]== 0:
        return array2D
    row = positionOfCapitaine[0]
    column = positionOfCapitaine[1]
    array2D[row][column] = "0"
    array2D[row - 1][column -1] = "*"
    return array2D

def moveCaptitaineTonextDownright(array2D,positionOfCapitaine):
    if len(positionOfCapitain)==0 or positionOfCapitain[1]==0:
        return array2D
    row = positionOfCapitaine[0]
    column = positionOfCapitaine[1]
    array2D[row][column] = "0"
    array2D[row +1][column +1] = "*"
    return array2D

def moveCaptitaineTonextDownleft(array2D,positionOfCapitaine):
    if len(positionOfCapitain)==0 or positionOfCapitain[1]==len(array2D)-1:
        return array2D
    row = positionOfCapitaine[0]
    column = positionOfCapitaine[1]
    array2D[row][column] = "0"
    array2D[row +1][column -1] = "*"
    return array2D


array2D=[
    ['0','0','0','0','0'],
    ['0','0','0','0','0'],
    ['0','0','*','0','0'],
    ['0','0','0','0','0'],
    ['0','0','0','0','0']
]
while True:
    positionOfCapitain = findPositionOfCapitain((array2D))
    direction = input()
    if direction =="R":
        array2D = moveCaptitaineTonextright(array2D,positionOfCapitain)
    elif direction =="L":
        array2D = moveCaptitaineTonextLeft(array2D,positionOfCapitain) 
    elif direction =="U":
        array2D = moveCaptitaineTonextUp(array2D,positionOfCapitain) 
    elif direction =="D":
        array2D = moveCaptitaineTonextDown(array2D,positionOfCapitain) 
    elif direction =='UR':   
        array2D = moveCaptitaineTonextUpright(array2D,positionOfCapitain) 
    elif direction =='UL':   
        array2D = moveCaptitaineTonextUpLeft(array2D,positionOfCapitain) 
    elif direction =='DL':   
        array2D = moveCaptitaineTonextDownleft(array2D,positionOfCapitain) 
    elif direction =='DR':   
        array2D = moveCaptitaineTonextDownright(array2D,positionOfCapitain) 
    output =""
    for i in range(len(array2D)):
        for J in range (len(array2D[i])):
            output+=array2D[i][J]+" "
        if i !=len(array2D)-1:
            output+="\n"
    print(output)